if __name__ == "__main__":
    from vodmltools.cli import app
    app()